#include <iostream>
#include "Date.h"
#include "CartaoAmigo.h"
#include "Menus.h"

int main() {
    loadClients();
    mainMenu();
    //firstOpen();
    return 0;
}